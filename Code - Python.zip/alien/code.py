#------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#       █████╗ ██╗     ██╗███████╗███╗  ██╗  
#      ██╔══██╗██║     ██║██╔════╝████╗ ██║  
#      ███████║██║     ██║█████╗  ██╔██╗██║  
#      ██╔══██║██║     ██║██╔══╝  ██║╚████║  
#      ██║  ██║███████╗██║███████╗██║ ╚███║  
#      ╚═╝  ╚═╝╚══════╝╚═╝╚══════╝╚═╝  ╚══╝  
#
#      ██╗███╗   ██╗██╗   ██╗ █████╗ ███████╗██╗ ██████╗ ███╗   ██╗
#      ██║████╗  ██║██║   ██║██╔══██╗██╔════╝██║██╔═══██╗████╗  ██║
#      ██║██╔██╗ ██║██║   ██║███████║███████╗██║██║   ██║██╔██╗ ██║
#      ██║██║╚██╗██║╚██╗ ██╔╝██╔══██║╚════██║██║██║   ██║██║╚██╗██║
#      ██║██║ ╚████║ ╚████╔╝ ██║  ██║███████║██║╚██████╔╝██║ ╚████║
#      ╚═╝╚═╝  ╚═══╝  ╚═══╝  ╚═╝  ╚═╝╚══════╝╚═╝ ╚═════╝ ╚═╝  ╚═══╝
#                                 A circuitpython demonstrator game.
#
# This game uses displayIO that handles sprites as objects that can be moved
# around instead of clearing and redrawing the display buffer for each frame.
#
# A sprite object is a tileGrid that is a defined area of a bitmap/ spritemap.
# The following parameters are used:
# •	spriteExample.x = 30 # x position of the object.
# •	spriteExample.y = 80 # y position of the object.
# •	spriteExample [0] = 2 # sprite index of the tile grid from the bitmap.
#
# Instead of adding and removing objects to/from the display group, they are
# simply moved outside the display area when not needed. Enemies and explosions
# that are not active are positioned at y = 128 (outside the display).
#
# When several sprites are used, like multiple enemies, an array holds a sprite
# object for the maximum number of enemies. Example: enemy #5 is hit and should
# be removed: enemyExample[4].y = 128
#
#
# TODO:
# * Test performance of stars
#
# DONE:
# 2023-06-03
# * Pause menu. Replaced font handling and key input
# 2023-04-04
# * ported code from c to circuitpython
# * optimized collision detection
# * added enemy movement
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                   # game hw config (keys & display)
import displayio            # display module
import adafruit_imageload   # import .bmp sprite map
import time                 # delay
import random               # random

# Static values
MAX_ENEMIES = 8
MAX_EXPLOSIONS = 8
MAX_BULLETS = 8
MAX_HEALTH = 4
MAX_STARS = 16
SCORE_DIGITS = 3

# Global variables

#------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# Main function
def main():
    # Create a background bitmap with random stars
    starMap = displayio.Bitmap(hw.display.width, hw.display.height, 2)
    palette = displayio.Palette(2)
    palette[0] = 0x000000
    palette[1] = 0xaaaaaa
    tile_grid = displayio.TileGrid(starMap, pixel_shader=palette)
    hw.displayGroup.append(tile_grid)
    for i in range(MAX_STARS):
        starMap[random.randint(0, 159), i * int(128 / MAX_STARS)] = 1

    # Load sprite_sheets from file (with identical palette)
    sprite_sheet, palette = adafruit_imageload.load("alien/space.bmp",bitmap=displayio.Bitmap,palette=displayio.Palette)
    explode_sheet, palette = adafruit_imageload.load("alien/explosion.bmp",bitmap=displayio.Bitmap,palette=displayio.Palette)

    # Player sprites
    plr = displayio.TileGrid(sprite_sheet, pixel_shader=palette,width = 1,height = 1,tile_width = 8,tile_height = 8)
    hw.displayGroup.append(plr)   # Add the sprite to the Group
    plr.x = 76
    plr.y = 100

    # Bullet sprites
    bullet=[]
    for i in range(MAX_BULLETS):
        bullet.append(displayio.TileGrid(sprite_sheet, pixel_shader=palette,width = 1,height = 1,tile_width = 8,tile_height = 8))
        hw.displayGroup.append(bullet[i])
        bullet[i][0] = 2 # bullet sprite ID

    # Enemy sprites
    enemy=[]
    for i in range(MAX_ENEMIES):
        enemy.append(displayio.TileGrid(sprite_sheet, pixel_shader=palette,width = 1,height = 1,tile_width = 8,tile_height = 8))
        hw.displayGroup.append(enemy[i])
        enemy[i][0] = 3 # enemy sprite ID
        enemy[i].y = 128 # disable enemy

    # Explosion sprites
    explode=[]
    for i in range(MAX_EXPLOSIONS):
        explode.append(displayio.TileGrid(explode_sheet, pixel_shader=palette,width = 1,height = 1,tile_width = 16,tile_height = 16))
        hw.displayGroup.append(explode[i])
        explode[i].y = 128 # outside display

    # Health sprites
    health=[]
    for i in range(MAX_HEALTH):
        health.append(displayio.TileGrid(sprite_sheet, pixel_shader=palette,width = 1,height = 1,tile_width = 8,tile_height = 8))
        hw.displayGroup.append(health[i])
        health[i][0] = 4 # full health sprite ID
        health[i].x = 130 + i * 6
        health[i].y = 0

    # Score object using hw.SpriteText and its scoreValue()
    scr = hw.SpriteText(0, 0, "000")
    loopCounter = 0
    plrScore = 0
    plrHealth = MAX_HEALTH

#------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

    # Main game loop
    while True:
        # move player
        if hw.key('L') and plr.x > 0:
            plr.x -=1
        if hw.key('R') and plr.x < 150:
            plr.x +=1
        if hw.key('U') and plr.y > 0:
            plr.y -=1
        if hw.key('D') and plr.y < 120:
            plr.y +=1
        # animate sprite every 16 frames
        plr[0] = loopCounter %32 >> 4

        # move active enemies
        nrEnemies = 0
        for i in range(MAX_ENEMIES):
            if enemy[i].y < 128:
                enemy[i].y +=1
                enemy[i].x += (nrEnemies % 2) + (loopCounter %16 >> 3) - 1
                nrEnemies += 1
                if collision(plr, enemy[i]):
                    plrHealth -= 1
                    health[MAX_HEALTH-plrHealth-1][0] = 5
                    explode[i].y = enemy[i].y
                    explode[i].x = enemy[i].x
                    explode[i][0] = 0
                    enemy[i].y = 128
                    if plrHealth <= 0:
                        plr.y = 128
                        gameOver = hw.SpriteText(45, 60, "Game Over!")
                        hw.display.refresh()
                        time.sleep(4)
                        hw.displayGroup.pop()
                        # Reset game settings
                        loopCounter = 0
                        plrScore = 0
                        scr.showValue(plrScore)
                        plrHealth = MAX_HEALTH
                        for e in enemy:
                            e.y = 128
                        for e in explode:
                            e.y = 128
                        for b in bullet:
                            b.y = -8
                        for h in health:
                            h[0] = 4
                        plr.x = 76
                        plr.y = 100
                        break

        # new enemy wave?
        if nrEnemies <= 0:
            nrEnemies = random.randint(1,MAX_ENEMIES)
            for i in range(nrEnemies):
                enemy[i].x = random.randint(30 , 120)
                enemy[i].y = -i * 10

        # fire
        if hw.key('A') and loopCounter % 16 == 0:
            for b in bullet:
                if b.y <= 0:
                    b.y=plr.y - 7
                    b.x=plr.x
                    break

        # update bullets
        for b in bullet:
            if b.y > -8:
                b.y -= 2
                # enemy hit?
                for i in range(len(enemy)):
                    if collision(enemy[i],b):
                        plrScore += 1
                        scr.showValue(plrScore)
                        explode[i].y = clamp(enemy[i].y, 0 , 127 - 16)
                        explode[i].x = clamp(enemy[i].x, 0 , 159 -16)
                        explode[i][0] = 0
                        enemy[i].y = 128
                        b.y = -8

        # update explosions
        if loopCounter %8 == 0:
            for e in explode:
                if e.y < 128:
                    e[0] += 1
                    if e[0] > 5:
                        e.y = 128

        # pause menu
        if hw.key_new('B'):            
            row1  = hw.SpriteText(45, 30, "Paused")
            row2  = hw.SpriteText(45, 50, "  Resume")
            row3  = hw.SpriteText(45, 60, "  Exit")
            sel   = hw.SpriteText(45, 50, ">")
            pos=0
            hw.display.refresh()
            while True:
                if hw.key_new('D') and pos<1:
                    pos+=1
                if hw.key_new('U') and pos>0:
                    pos-=1           
                if hw.key_new('A') or hw.key_new('B'):
                    if pos == 0:
                        break                           # resume game
                    else:                               # exit game
                        return()
                sel.group.y=50+pos*10
                hw.display.refresh()
            for i in range(4):                          # remove menu
                hw.displayGroup.pop()
            tile_grid[0] = 0                            # refresh background
            hw.display.refresh()

        loopCounter += 1
        hw.display.refresh(target_frames_per_second = 60)


#------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# Binary collision detection (since abs() is too slow)
def collision(a,b):
    y = (a.y - b.y) & 0xf8
    if y == 0 or y == 0xf8:
        x = (a.x - b.x) & 0xf8
        if x == 0 or x == 0xf8:
            return 1
    return 0

def clamp(t, min, max):
    if t < min:
        t = min
    if t > max:
        t = max
    return t

if __name__ == "__main__":
    main()