# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#
#        /$$$$$$   /$$$$$$  /$$   /$$  /$$$$$$
#       /$$__  $$ /$$$_  $$| $$  | $$ /$$__  $$
#      |__/  \ $$| $$$$\ $$| $$  | $$| $$  \ $$
#        /$$$$$$/| $$ $$ $$| $$$$$$$$|  $$$$$$/
#       /$$____/ | $$\ $$$$|_____  $$ >$$__  $$
#      | $$      | $$ \ $$$      | $$| $$  \ $$
#      | $$$$$$$$|  $$$$$$/      | $$|  $$$$$$/
#      |________/ \______/       |__/ \______/
#            A circuitpython demonstrator game.
#
# Description: A Circut Python implementation of 2048
# Knowledge level: Medium
# Authors: Marcus, Niklas, Alexander and Johan
#
# TODO:
# * keep tiles instead of pop and new?
#
# DONE:
# 2023-05-30    * making it compatible with hw.py (replaced input and graphics functions)
# 2023-03-15    * initial game implementation
#
# This code is open source under MIT License.
# ******************************************************************************

import hw
import displayio
import adafruit_imageload
import random
import time

# We store the board as a matrix. When presenting the numbers we take x -> 2**x
matrix = [
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
]

def draw_number_in_box(i, j):
    # Dynamic tile color
    inner_bitmap = displayio.Bitmap(30, 30, 1)
    inner_palette = displayio.Palette(1)
    if matrix[j][i]:
        inner_palette[0] = (matrix[j][i] + 4) << 20
    else:
        inner_palette[0] = 0
    inner_sprite = displayio.TileGrid(inner_bitmap, pixel_shader=inner_palette, x=i*32+17, y=j*32+1)#x=98, y=2,
    hw.displayGroup.append(inner_sprite)

    # Draw the number in the box
    sheet, palette = adafruit_imageload.load("lib/font.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette)
    palette.make_transparent(0)
    grp = hw.displayio.Group()
    hw.displayGroup.append(grp)
    value = 2 ** matrix[j][i]
    if value > 1:
        xpos=32
        for digit in [int(x) for x in str(value)]:
            num = hw.displayio.TileGrid(sheet, pixel_shader=palette, width=1, height=1, tile_width=8, tile_height=8)
            grp.append(num)
            num.x = i*32 + xpos - len(str(value))*3
            num.y = j*32 + 12
            num[0] = digit+16
            xpos += 7


def draw_all_numbers():
    for i in range(4):
        for j in range(4):
            draw_number_in_box(i, j)
    hw.display.refresh()


def clear_numbers_from_board():
    for _ in range(32):
        hw.displayGroup.pop()


def _merge_left(mat):
    def _left_align(x):
        for i in range(3):
            for j in range(3-i):
                if x[j] == 0:
                    x[j] = x[j+1]
                    x[j+1] = 0
    def _combine(x):
        for i in range(3):
            if (x[i] == x[i+1]) and x[i]:
                x[i] = x[i] + 1
                x[i+1] = 0

    for row in mat:
        _left_align(row)
        _combine(row)
        _left_align(row)


def rotate_matrix(mat, rotations):
    new_mat = [[0, 0, 0, 0], [0, 0, 0, 0],[0, 0, 0, 0],[0, 0, 0, 0]]
    for _ in range(rotations):
        for i in range(4):
            for j in range(4):
                new_mat[i][j] = mat[3-j][i]
        for i in range(4):
            for j in range(4):
                mat[i][j] = new_mat[i][j]


def merge_left():
    _merge_left(matrix)


def merge_right():
    rotate_matrix(matrix, 2)
    _merge_left(matrix)
    rotate_matrix(matrix, 2)


def merge_up():
    rotate_matrix(matrix, 3)
    _merge_left(matrix)
    rotate_matrix(matrix, 1)


def merge_down():
    rotate_matrix(matrix, 1)
    _merge_left(matrix)
    rotate_matrix(matrix, 3)


def add_random_number_to_board():
    max_num = max(map(max, matrix)) or 1
    min_num = 1
    new_num = random.randint(min_num, max_num)

    while True:
        i_try = random.randint(0, 3)
        j_try = random.randint(0, 3)
        if matrix[i_try][j_try] == 0:
            matrix[i_try][j_try] = new_num
            break

def main():
    # Create a bitmap for the grid
    imageGrid = displayio.Bitmap(hw.display.width, hw.display.height, 2)
    palette = displayio.Palette(2)
    palette[0] = 0x000000
    palette[1] = 0xaaaaaa
    line_grid = displayio.TileGrid(imageGrid, pixel_shader=palette)
    hw.displayGroup.append(line_grid)
    # Draw the grid
    for y in [0, 32, 64, 96, 127]:
        for x in range(128):
            imageGrid[x+16, y] = 1
    for x in [0, 32, 64, 96, 127]:
        for y in range(128):
            imageGrid[x+16, y] = 1

    # Init board
    for i in range(4):
        for j in range(4):
            matrix[i][j] = 0
    add_random_number_to_board()
    draw_all_numbers()

    # Main game loop
    while True:
        # Game input
        if hw.key_nav():
            if hw.key_new('U'):
                merge_up()
            if hw.key_new('D'):
                merge_down()
            if hw.key_new('R'):
                merge_right()
            if hw.key_new('L'):
                merge_left()
            add_random_number_to_board()
            draw_all_numbers()
            while hw.key_nav():
                time.sleep(0.02)

        # Pause menu
        if hw.key_new('A') or hw.key_new('B'):
            row1  = hw.SpriteText(38+20, 50, "Paused")
            row2  = hw.SpriteText(38+22, 70, " Resume")
            row3  = hw.SpriteText(38+22, 80, " Exit")
            sel   = hw.SpriteText(38+19, 70, ">")
            hw.display.refresh()
            pos = 0
            while True:
                if hw.key_new('D'): pos += 1
                if pos > 1: pos = 1
                if hw.key_new('U'): pos -= 1
                if pos < 0: pos = 0
                if hw.key_new('A') or hw.key_new('B'):
                    if pos == 0:                        # resume game
                        break
                    if pos == 1:                        # exit game
                        return()
                sel.group.y = 70 + pos * 10
                hw.display.refresh()
            # remove menu
            for i in range(4):
                hw.displayGroup.pop()
            line_grid[0] = 0                            # redraw grid
            hw.display.refresh()                        # update display


if __name__ == "__main__":
    main()