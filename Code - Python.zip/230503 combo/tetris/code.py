# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#
#           ********** ******** ********** *******    **   ********
#          /////**/// /**///// /////**/// /**////**  /**  **//////
#              /**    /**          /**    /**   /**  /** /**
#              /**    /*******     /**    /*******   /** /*********
#              /**    /**////      /**    /**///**   /** ////////**
#              /**    /**          /**    /**  //**  /**        /**
#              /**    /********    /**    /**   //** /**  ********
#              //     ////////     //     //     //  //  ////////
#                                A circuitpython demonstrator game.
#
# Description: A Tetris implementation written to be fun to play
# Knowledge level: Medium
#
# This game uses displayIO that handles sprites as objects that can be moved
# around instead of clearing and redrawing the display buffer for each frame.
#   A sprite object is a tileGrid (a defined area of a bitmap/ spritemap).
#   The following parameters are used:
#   * spriteExample.x = 30 # x position of the object.
#   * spriteExample.y = 80 # y position of the object.
#   * spriteExample[0] = 2 # sprite index of the tile grid from the bitmap.
#
# TODO:
# * level select in pause menu
# * implement "B" mode?
# * implement multi player over Wi-Fi?
# * non volatile high score?
# * sound would be nice...
#
# DONE:
# 2022-04-29
# * replaced global variables with classes...
# 2022-04-15
# * added shadow tetrominoe
# * fixed Delayed Auto Shift
# 2022-04-04
# * ported code from c to circuitpython
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                           # game hw config (keys & display)
import displayio                    # display module
import adafruit_imageload           # import .bmp sprite map
import time                         # delay
import random                       # random

# Static values
MAX_COL = 10                        #
MAX_ROW = 18                        #
POINTS = [0, 40, 100, 300, 1200]    #
SPEED = [53, 49, 45, 41, 37, 33, 28, 22, 17, 11, 10, 9, 8, 7, 6, 6, 5, 5, 4, 4, 3]
DAS_F = 23                          # frames until first Delay Auto Shift
DAS_R = 9                           # frames until repeat Delay Auto Shift

# rotation matrix (tetrominoes) in semi readable form (from GBA)
#
# I=1  J=2  L=3  O=4  S=5  T=6  Z=7
# 0000 0000 0000 0000 0000 0000 0000
# 0000 2220 3330 0440 0550 6660 7700
# 1111 0020 3000 0440 5500 0600 0770
# 0000 0000 0000 0000 0000 0000 0000
#
# 0100 0200 3300 0000 5000 0600 0700
# 0100 0200 0300 0440 5500 6600 7700
# 0100 2200 0300 0440 0500 0600 7000
# 0100 0000 0000 0000 0000 0000 0000
#
# 0000 2000 0030 0000 0000 0600 0000
# 0000 2220 3330 0440 0550 6660 7700
# 1111 0000 0000 0440 5500 0000 0770
# 0000 0000 0000 0000 0000 0000 0000
#
# 0100 0220 0300 0000 5000 0600 0700
# 0100 0200 0300 0440 5500 0660 7700
# 0100 0200 0330 0440 0500 0600 7000
# 0100 0000 0000 0000 0000 0000 0000
#
tetrominoe = [
  [0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0, 0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0, 0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0, 0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0],
  [0,0,0,0,2,2,2,0,0,0,2,0,0,0,0,0, 0,2,0,0,0,2,0,0,2,2,0,0,0,0,0,0, 2,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0, 0,2,2,0,0,2,0,0,0,2,0,0,0,0,0,0],
  [0,0,0,0,3,3,3,0,3,0,0,0,0,0,0,0, 3,3,0,0,0,3,0,0,0,3,0,0,0,0,0,0, 0,0,3,0,3,3,3,0,0,0,0,0,0,0,0,0, 0,3,0,0,0,3,0,0,0,3,3,0,0,0,0,0],
  [0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0, 0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0, 0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0, 0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0],
  [0,0,0,0,0,5,5,0,5,5,0,0,0,0,0,0, 5,0,0,0,5,5,0,0,0,5,0,0,0,0,0,0, 0,0,0,0,0,5,5,0,5,5,0,0,0,0,0,0, 5,0,0,0,5,5,0,0,0,5,0,0,0,0,0,0],
  [0,0,0,0,6,6,6,0,0,6,0,0,0,0,0,0, 0,6,0,0,6,6,0,0,0,6,0,0,0,0,0,0, 0,6,0,0,6,6,6,0,0,0,0,0,0,0,0,0, 0,6,0,0,0,6,6,0,0,6,0,0,0,0,0,0],
  [0,0,0,0,7,7,0,0,0,7,7,0,0,0,0,0, 0,7,0,0,7,7,0,0,7,0,0,0,0,0,0,0, 0,0,0,0,7,7,0,0,0,7,7,0,0,0,0,0, 0,7,0,0,7,7,0,0,7,0,0,0,0,0,0,0]]


# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# Main function
def main():
    global playField

    # Load sprite_sheets from file
    # path=__file__[0:__file__.rfind('/')+1]
    sprite_sheet, palette = adafruit_imageload.load(
        "tetris/tetris_sprite.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette)
    palette.make_transparent(0)

    class key:
        def __init__(self, key):
            self.key = key
            self.prev = 0

        def test(self):
            self.prev = self.prev + 1 if not self.key.value else 0
            if self.prev == 1 or (self.prev > DAS_F and self.prev % DAS_R == 0):
                return True
            return False

    class Sprite:
        def __init__(self, grp, sheet, palette):
            self.s = displayio.TileGrid(
                sheet, pixel_shader=palette, width=1, height=1, tile_width=8, tile_height=8)
            grp.append(self.s)

        def setSprite(self, t):
            self.s[0] = t

        def getSprite(self):
            return (self.s[0])

        def setPos(self, x, y):
            self.s.x = x
            self.s.y = y

    class Shape:
        def __init__(self):
            self.grp = displayio.Group()
            hw.displayGroup.append(self.grp)
            self.id = 0
            self.x = 3
            self.y = -2
            self.r = 0
            self.grp.x = 16 + self.x * 7
            self.grp.y = self.y * 7
            self.array = []
            for i in range(16):
                s = Sprite(self.grp, sprite_sheet, palette)
                s.setPos(int(i % 4) * 7, int(i/4) * 7)
                self.array.append(s)

        def update(self, rot, block):
            for i in range(16):
                self.array[i].s[0] = block if tetrominoe[self.id][i +
                                                                  rot * 16] != 0 else 0

        def drop(self, y, field):
            if field.testPos(plr.id, plr.x, y, plr.r):
                while field.testPos(plr.id, plr.x, y, plr.r):
                    y += 1
                self.grp.x = plr.grp.x
                self.grp.y = (y - 1) * 7
            else:
                self.grp.y = -100

    class Field:
        def __init__(self):
            self.array = []
            for i in range(MAX_ROW * MAX_COL):
                s = Sprite(hw.displayGroup, sprite_sheet, palette)
                s.setPos(16 + (i % MAX_COL) * 7, int(i / MAX_COL) * 7)
                self.array.append(s)
            self.reset(0)

        def setBlock(self, x, y, block):
            self.array[y * MAX_COL + x].setSprite(block)

        def getBlock(self, x, y):
            return (self.array[y * MAX_COL + x].getSprite())

        def testPos(self, id, x, y, r):
            for cy in range(4):
                for cx in range(4):
                    block = tetrominoe[id][r*16 + cy*4 + cx]
                    if block != 0 and (x+cx < 0 or x+cx >= MAX_COL):
                        return 0        # block is outside walls
                    if block != 0 and y+cy > 0:
                        if y+cy >= MAX_ROW:
                            return 0    # block is below field
                        if self.getBlock(x+cx, y+cy) != 0:
                            # block interferes with previous tetrominoes (abort)
                            return 0
            return 1    # tetrominoe movement is ok (return true)

        def refresh(self):
            for s in self.array:
                s.setSprite(s.getSprite())
            
        def reset(self, spriteId):
            for s in self.array:
                s.setSprite(spriteId)

    class Wall:
        def __init__(self, x):
            self.grp = displayio.Group()
            hw.displayGroup.append(self.grp)
            self.array = []
            for i in range(21):
                s = Sprite(self.grp, sprite_sheet, palette)
                s.setPos(x, i * 6)
                s.setSprite(8)
                self.array.append(s)

    # instantiate classes
    keyU = key(hw.KEY_U)                            # Key up with Delay Auto Shift
    keyD = key(hw.KEY_D)                            # Down...
    keyR = key(hw.KEY_R)                            #
    keyL = key(hw.KEY_L)                            #
    keyA = key(hw.KEY_A)                            #
    keyB = key(hw.KEY_B)                            #
    playField = Field()                             # Playfield (dropped Tetrominoes)
    shadow = Shape()                                # Shadow Tetrominoe
    plr = Shape()                                   # Player (falling) tetrominoe
    wall1 = Wall(8)                                 # Left brick column
    wall2 = Wall(87)                                # Right brick column
    scrtxt = hw.SpriteText(110, 5, "SCORE")         # Score text
    scr = hw.SpriteText(110, 15, "000000")          # Score value
    nxttxt = hw.SpriteText(110, 30, "NEXT")         # Next text
    nxt = Shape()                                   # Next Tetrominoe
    nxt.grp.x = 120                                 #
    nxt.grp.y = 40                                  #
    lvltxt = hw.SpriteText(110, 70, "LEVEL")        #
    lvl = hw.SpriteText(110, 80, "00")              #
    lnstxt = hw.SpriteText(110, 100, "LINES")       #
    lns = hw.SpriteText(110, 110, "0000")           #                 
    gameOver = hw.SpriteText(16, 255, "Game Over!") # Outside active display area  

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

    # init game
    score = 0
    lines = 0
    level = 0
    frameCounter = 0
    plr.id = random.randint(0, 6)
    nxt.id = random.randint(0, 6)
    shadow.id = plr.id
    plr.update(plr.r, plr.id + 1)
    shadow.update(plr.r, 10)
    nxt.update(0, nxt.id + 1)
    shadow.drop(15, playField)

    # main game loop
    while True:
        # Move right
        if keyR.test() and playField.testPos(plr.id, plr.x+1, plr.y, plr.r):
            plr.x += 1
            plr.grp.x = 16 + plr.x * 7

        # Move left
        if keyL.test() and playField.testPos(plr.id, plr.x-1, plr.y, plr.r):
            plr.x -= 1
            plr.grp.x = 16 + plr.x * 7

        # Rotate ClockWise
        if keyA.test():
            tmp = plr.r + 1
            if tmp > 3:
                tmp = 0
            if playField.testPos(plr.id, plr.x, plr.y, tmp):
                plr.r = tmp
                plr.update(plr.r, plr.id+1)
                shadow.update(plr.r, 10)

        # Rotate CounterClockWise
        if keyB.test():
            tmp = plr.r - 1
            if tmp < 0:
                tmp = 3
            if playField.testPos(plr.id, plr.x, plr.y, tmp):
                plr.r = tmp
                plr.update(plr.r, plr.id+1)
                shadow.update(plr.r, 10)

        # Soft drop
        if keyD.test() and playField.testPos(plr.id, plr.x, plr.y+1, plr.r):
            plr.y += 1
            plr.grp.y = plr.y * 7

        # Pause menu
        if keyU.test():
            row1 = hw.SpriteText(20, 40, "Paused")
            row2 = hw.SpriteText(20, 50, "  Resume")
            row3 = hw.SpriteText(20, 60, "  Exit")
            sel = hw.SpriteText(20, 50, ">")
            pos = 0
            while True:
                sel.group.y = 50 + pos * 10
                hw.display.refresh()
                if keyD.test() and pos < 1:
                    pos += 1
                    print(pos)
                if keyU.test() and pos > 0:
                    pos -= 1
                    print(pos)
                if keyA.test():
                    while not hw.KEY_A.value:   # wait until key is released...
                        time.sleep(0.02)
                    if pos == 0:
                        break                   # resume game
                    else:       
                        return()                # exit game
            for i in range(4):                  # remove menu
                hw.displayGroup.pop()
            playField.refresh()
            hw.display.refresh()

        # Auto drop
        if frameCounter % SPEED[level] == 0:
            if playField.testPos(plr.id, plr.x, plr.y+1, plr.r):
                # free to move down tetrominoe
                plr.y += 1
                plr.grp.y = plr.y * 7
            else:
                # save tetrominoe on field
                for cy in range(4):
                    for cx in range(4):
                        block = tetrominoe[plr.id][plr.r*16 + cy*4 + cx]
                        if block != 0 and cy+plr.y >= 0:
                            playField.setBlock(plr.x+cx, plr.y+cy, block)

                # find full rows, remove and move down rows above
                cRow = 0
                for cy in range(17, 0, -1):
                    i = 0
                    for cx in range(MAX_COL):
                        playField.setBlock(
                            cx, cy+cRow, playField.getBlock(cx, cy))
                        if playField.getBlock(cx, cy) != 0:
                            i += 1
                        if cRow > 0:
                            playField.setBlock(cx, cy, 0)
                    if i == MAX_COL:
                        cRow += 1
                        lines += 1

                # level handling
                # *** add start count multiplier (start at level4 stays 50 lines)
                level = int(lines / 10)
                if level > len(SPEED):
                    level = len(SPEED)

                # game over?
                if (plr.y < 0):
                    gameOver.group.y = 62
                    playField.reset(10)
                    hw.display.refresh(target_frames_per_second=60)
                    hw.display.refresh(target_frames_per_second=60)
                    time.sleep(3)
                    gameOver.group.y = 255
                    # Reset game settings
                    frameCounter = 0
                    score = 0
                    lines = 0
                    level = 0
                    plr.id = random.randint(0, 6)
                    shadow.id = plr.id
                    nxt.id = random.randint(0, 6)
                    playField.reset(0)
                    time.sleep(1)

                # update score, level, lines
                score += POINTS[cRow] * (level + 1)
                scr.showValue(score)
                lvl.showValue(level)
                lns.showValue(lines)

                # init next tetrominoe
                plr.id = nxt.id
                plr.x = 3
                plr.y = -2
                plr.r = 0
                plr.grp.x = 16 + plr.x * 7
                plr.grp.y = plr.y * 7
                plr.update(plr.r, plr.id + 1)
                shadow.id = plr.id
                shadow.update(plr.r, 10)
                nxt.id = random.randint(0, 6)
                nxt.update(0, nxt.id + 1)

        shadow.drop(plr.y+1, playField)
        frameCounter += 1
        hw.display.refresh(target_frames_per_second=60)

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

if __name__ == "__main__":
    main()
