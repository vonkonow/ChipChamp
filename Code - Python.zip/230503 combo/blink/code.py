import board                                        # input output
import digitalio                                    # input output config
import time                                         # delay

print("Hello World!")

builtinLed = digitalio.DigitalInOut(board.IO15)     # Builtin LED = IO15
builtinLed.direction = digitalio.Direction.OUTPUT   # Set as output
while True:
    time.sleep(0.2)                                 # 200ms delay
    builtinLed.value = not builtinLed.value         # Toggle
