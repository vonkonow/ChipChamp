#------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#
#________/\\\\\\\\\__/\\\____________________________________/\\\\\\\\\__/\\\__________________________________________________________
# _____/\\\////////__\/\\\_________________________________/\\\////////__\/\\\__________________________________________________________
#  ___/\\\/___________\/\\\__________/\\\___/\\\\\\\\\____/\\\/___________\/\\\______________________________________________/\\\\\\\\\__
#   __/\\\_____________\/\\\_________\///___/\\\/////\\\__/\\\_____________\/\\\__________/\\\\\\\\\_______/\\\\\__/\\\\\____/\\\/////\\\_
#    _\/\\\_____________\/\\\\\\\\\\___/\\\_\/\\\\\\\\\\__\/\\\_____________\/\\\\\\\\\\__\////////\\\____/\\\///\\\\\///\\\_\/\\\\\\\\\\__
#     _\//\\\____________\/\\\/////\\\_\/\\\_\/\\\//////___\//\\\____________\/\\\/////\\\___/\\\\\\\\\\__\/\\\_\//\\\__\/\\\_\/\\\//////___
#      __\///\\\__________\/\\\___\/\\\_\/\\\_\/\\\__________\///\\\__________\/\\\___\/\\\__/\\\/////\\\__\/\\\__\/\\\__\/\\\_\/\\\_________
#       ____\////\\\\\\\\\_\/\\\___\/\\\_\/\\\_\/\\\____________\////\\\\\\\\\_\/\\\___\/\\\_\//\\\\\\\\/\\_\/\\\__\/\\\__\/\\\_\/\\\_________
#        _______\/////////__\///____\///__\///__\///________________\/////////__\///____\///___\////////\//__\///___\///___\///__\///__________
#
#
# Description: A simple loader for other games
# Knowledge level: Easy
#
# TODO:
# load games from server?
# add music?
#
# DONE:
# 2023-05-31    removed the need for image loading array
# 2023-05-02    implemented first version
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                                               # game hw config (keys & display)
import displayio                                        # display module
import adafruit_imageload                               # import .bmp images
import time                               # import .bmp images

from tetris import code as tetris
from sokoban import code as sokoban
from sky import code as sky
from alien import code as alien
from g2048 import code as g2048
from dino import code as dino
programs = ["tetris","alien","g2048","dino","sokoban", "sky"]

class Image():
    def __init__(self, image):
        self.load(image)
    def replace(self, image):
        hw.displayGroup.pop()
        self.load(image)
    def load(self, image):
        load_bitmap, load_palette = adafruit_imageload.load(image,bitmap=displayio.Bitmap,palette=displayio.Palette)
        load_tile = displayio.TileGrid(load_bitmap, pixel_shader=load_palette,width = 1,height = 1,tile_width = 160,tile_height = 128)
        hw.displayGroup.append(load_tile)               # add sprite to group
        hw.display.refresh()                            # update screen
    def clear(self, color):
        hw.displayGroup.pop()                           # remove load image
        load_bitmap = displayio.Bitmap(160, 128, 1)     # create black bitmap
        load_palette = displayio.Palette(1)
        load_palette[0] = color
        load_sprite = displayio.TileGrid(load_bitmap, pixel_shader=load_palette, x=0, y=0)
        hw.displayGroup.append(load_sprite)
        hw.display.refresh()                            # clear screen
        hw.displayGroup.pop()                           # remove object

def main():
    pos = 0
    bg = Image(programs[pos]+"/"+programs[pos]+"_load.bmp")

    while True:
        # next game
        if hw.key_new('R') and pos < len(programs) - 1:
            pos += 1
            bg.replace(programs[pos]+"/"+programs[pos]+"_load.bmp")
        # prev game
        if hw.key_new('L') and pos > 0:
            pos -= 1
            bg.replace(programs[pos]+"/"+programs[pos]+"_load.bmp")
        # load game
        if hw.key_ab():
            print("loading: "+programs[pos])
            bg.clear(0x000000)
            eval(programs[pos]+".main()")               # load game
            for i in range(len(hw.displayGroup)):       # clear display (remove game objects)
                hw.displayGroup.pop()
            bg.load(programs[pos]+"/"+programs[pos]+"_load.bmp")
            while hw.key_any():                         # wait until key is released...
                time.sleep(0.02)                        # debounce

if __name__ == "__main__":
    main()