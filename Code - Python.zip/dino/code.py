# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#    /^^^^^                                    /^^                             
#    /^^   /^^  /^                             /^^                             
#    /^^    /^^   /^^ /^^     /^^              /^^/^^  /^^/^^^ /^^ /^^ /^ /^^  
#    /^^    /^^/^^ /^^  /^^ /^^  /^^           /^^/^^  /^^ /^^  /^  /^^/^  /^^ 
#    /^^    /^^/^^ /^^  /^^/^^    /^^          /^^/^^  /^^ /^^  /^  /^^/^   /^^
#    /^^   /^^ /^^ /^^  /^^ /^^  /^^      /^   /^^/^^  /^^ /^^  /^  /^^/^^ /^^ 
#    /^^^^^    /^^/^^^  /^^   /^^          /^^^^    /^^/^^/^^^  /^  /^^/^^     
#              A circuitpython demonstrator game.                      /^^  
#                                
#
# Description: A Simple Dino jump game that is not complete.
# You have to write the remaining code in order to play the game :)
# Knowledge level: Easy
#
# This game uses displayIO that handles sprites as objects that can be moved
# around instead of clearing and redrawing the display buffer for each frame.
#   A sprite object is a tileGrid (a defined area of a bitmap/ spritemap).
#   The following parameters are used:
#   * spriteExample.x = 30 # x position of the object.
#   * spriteExample.y = 80 # y position of the object.
#   * spriteExample[0] = 2 # sprite index of the tile grid from the bitmap.
#
# TODO:
# * Jump is not implelented...
#
# DONE:
# 2023-04-30
# * Created sprites and wrote basic game functions
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                           # game hw config (keys & display)
import displayio                    # display module
import adafruit_imageload           # import .bmp sprite map
import time                         # delay
import random                       # random

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# Main function
def main():
    
    # Load sprite_bitmaps from file (0,1 = dino. 2,3 = cacti. 4 = cloud. 5,6,7,8,9 = ground)
    sprite_bitmap, sprite_palette = adafruit_imageload.load("dino/dino_sprite.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette)
    
    # Sprite object (tile grid)
    class Sprite:
        def __init__(self,x,y,id):
            self.s = displayio.TileGrid(sprite_bitmap, pixel_shader=sprite_palette, width=1, height=1, tile_width=24, tile_height=24)
            self.s.x = x
            self.s.y = y
            self.s[0] = id
            hw.displayGroup.append(self.s)
        def setSprite(self, id):
            self.s[0] = id
        def getSprite(self):
            return (self.s[0])
        def setPos(self, x, y):
            self.s.x = x
            self.s.y = y

    # Scrolling background object that moves to the left (update) and can restart (new)
    class aniBG:
        # Create a new object (x,y position, min and max sprite id (randomized))
        def __init__(self, x, y, min, max):
            self.min = min
            self.max = max
            self.done = False       # False = the object is moving. True = ready to be restarted
            self.sprite = Sprite(x,y,random.randint(min, max))
        # Scroll the object sideways
        def update(self, speed):
            self.sprite.s.x -= speed
            if self.sprite.s.x <= -24:
                self.done = True
        # Reset the object (move it to the right so it can scroll again)
        def new(self):
            self.done = False
            self.sprite.s.x = 24 * 7
            self.sprite.setSprite(random.randint(self.min, self.max))

    # Create a white background
    white_palette = displayio.Palette(1)
    white_palette[0] = 0xFFFFFF  # White
    white_sprite = displayio.TileGrid(displayio.Bitmap(160, 128, 1), pixel_shader=white_palette, x=0, y=0)
    hw.displayGroup.append(white_sprite)

    # Instantiate classes (copy the class to an object)
    stones = []                                         # Create stones obect
    for i in range(8):                                  # Number of stones
        stones.append(aniBG(i*24, 92, 5, 9))            # Add stone
    cacti = []                                          # Create cacti object
    for i in range(2):                                  # Number oc cacti
        cacti.append(aniBG(300 + i * 100, 88, 2, 3))    # Add cactus
    sprite_palette.make_transparent(0)                  # Make background transparent
    dino = Sprite(20,90,0)                              # Player sprite
    scrtxt = hw.SpriteText(110, 5, "SCORE")             # Score text
    scr = hw.SpriteText(110, 15, "000000")              # Score value
    scr.bwPalette[0] = 0xFFFFFF                         # White background
    scr.bwPalette[1] = 0x444444                         # Grey textcolor

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

    # init game
    score = 0
    scrollSpeed = 2
    frameCounter = 0
    cactiDistance = 0
    jump_height = 0
    jump_direction = 1
    
    # inform the user that the lack of jump is not a bug...
    row1 = hw.SpriteText(20, 40, "This game is not")
    row2 = hw.SpriteText(20, 50, "complete. You have ")
    row3 = hw.SpriteText(20, 60, "to program the ")
    row3 = hw.SpriteText(20, 70, "missing code...")
    hw.display.refresh()
    time.sleep(3)
    for i in range(4):
        hw.displayGroup.pop()
    white_sprite[0] = 0                     # refresh background
    hw.display.refresh()                    # redraw display
    

    # main game loop
    while True:
        # Jump?
        if hw.key_new('A'):
            # something seems to be missing here...
            # manipulate dino.s.y and see what happens
            pass

        # animate dino
        if frameCounter % 16 == 0:
            dino.setSprite(1)
        elif frameCounter % 8 == 0:
            dino.setSprite(0)

        # scroll ground
        for stone in stones:
            stone.update(scrollSpeed)
            if stone.done:
                stone.new()

        # create and scroll cacti
        cactiDistance += 1
        for cactus in cacti:
            cactus.update(scrollSpeed)
            if cactus.done and cactiDistance > 40:
                if random.randint(0, 200) != 0:
                    cactus.new()
                    cactiDistance = 0

        # show score
        if frameCounter % 3 == 0:
            score += 1
            scr.showValue(score)
            
        # pause menu
        if hw.key_new('B'):
            row1 = hw.SpriteText(20, 40, "Paused")
            row2 = hw.SpriteText(20, 50, "  Resume")
            row3 = hw.SpriteText(20, 60, "  Exit")
            sel = hw.SpriteText(20, 50, ">")
            pos = 0
            while True:
                sel.group.y = 50 + pos * 10
                hw.display.refresh()
                if hw.key_new('D') and pos < 1:
                    pos += 1
                    print(pos)
                if hw.key_new('U') and pos > 0:
                    pos -= 1
                    print(pos)
                if hw.key_new('A') or hw.key_new('B'):
                    if pos == 0:
                        break                           # resume game
                    else:       
                        scr.bwPalette[0] = 0x000000     # Restore palette
                        scr.bwPalette[1] = 0xFFFFFF     # Restore palette
                        return()                        # exit game
            for i in range(4):                          # remove menu
                hw.displayGroup.pop()                   #
            white_sprite[0] = 0                         # refresh background
            hw.display.refresh()                        # redraw display
            
        # game over?
        for cactus in cacti:
            if collision(dino.s, cactus.sprite.s):
                gameOver = hw.SpriteText(50, 60, "Game Over!")
                hw.display.refresh()
                time.sleep(3)
                hw.displayGroup.pop()
                white_sprite[0] = 0                     # refresh background
                hw.display.refresh()                    # redraw display
                # Reset game settings
                for i in range(len(cacti)):
                    cacti[i].sprite.s.x = 300 + i * 100
                score = 0
        frameCounter += 1
        hw.display.refresh(target_frames_per_second=100)

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# collision detection (between two tile grid objects)
def collision(a,b):
    y = (a.y - b.y)
    if y > -16 and y < 16:
        x = (a.x - b.x)
        if x > -16 and x < 16:
            return 1
    return 0

if __name__ == "__main__":
    main()
