import board # input output
import digitalio # input output config
import busio # SPI for display
import displayio # display module
from adafruit_st7735r import ST7735R # display driver
import adafruit_imageload           # import .bmp sprite map

# Define control pins
KEY_U_PIN = board.IO7
KEY_D_PIN = board.IO3
KEY_R_PIN = board.IO5
KEY_L_PIN = board.IO2
KEY_A_PIN = board.IO4
KEY_B_PIN = board.IO6

# Init control pins (inputs with weak pull up)
btn=[]
btn_pin=[KEY_U_PIN, KEY_D_PIN, KEY_R_PIN, KEY_L_PIN, KEY_A_PIN, KEY_B_PIN]
for b in btn_pin:
    btn.append(digitalio.DigitalInOut(b))
    btn[-1].direction = digitalio.Direction.INPUT
    btn[-1].pull=digitalio.Pull.UP
prev=[0,0,0,0,0,0]
order = ['U','D','R','L','A','B']
KEY_U = btn[0]
KEY_D = btn[1]
KEY_R = btn[2]
KEY_L = btn[3]
KEY_A = btn[4]
KEY_B = btn[5]

# Test if specific key is pressed
def key(key):
    pos = order.index(key)
    if btn[pos].value:
        prev[pos] = 0
    return not btn[pos].value

# Test if any key is pressed
def key_any():
    for i in range(6):
        if btn[i].value == 0:
            return True
        prev[i] = 0
    return False

# Test if any navigation key is pressed
def key_nav():
    for i in range(0,4):
        if btn[i].value == 0:
            return True
        prev[i] = 0
    return False

# Test if A or B key is pressed
def key_ab():
    for i in range(4,6):
        if btn[i].value == 0:
            return True
        prev[i] = 0
    return False

# Test if specific key is new (pressed now, but released last check)
def key_new(key):
    pos = order.index(key)
    if not btn[pos].value and prev[pos] == 0:
        prev[pos] = 1 
        return True
    if btn[pos].value:
        prev[pos] = 0
    return False

# Setup builtin (blue) LED 
builtinLed = digitalio.DigitalInOut(board.IO15)     # Builtin LED = IO15
builtinLed.direction = digitalio.Direction.OUTPUT   # Set as output

# Define display pins
PICO_PIN = board.IO35 # data
CLK_PIN = board.IO36 # clock
RST_PIN = board.IO37 # reset
CS_PIN = board.IO40 # chip select
DC_PIN = board.IO39 # data/command
BL_PIN = board.IO38 # backlight

# Initialize the display
displayio.release_displays()
spi = busio.SPI(clock=CLK_PIN, MOSI=PICO_PIN)
dispWidth = 160
dispHeight = 128
display_bus = displayio.FourWire(spi, command=DC_PIN, chip_select=CS_PIN, reset=RST_PIN)
display = ST7735R(
    display_bus,
    width=dispWidth,
    height=dispHeight,
    bgr=True,
    rowstart=1, # 0 on some panels...
    colstart=2, # 0 on some panels...
    rotation=270,
    auto_refresh=False
)
bl = digitalio.DigitalInOut(BL_PIN)
bl.direction = digitalio.Direction.OUTPUT
bl.value = True # Turn on backlight

# Create displayIO group to hold all sprites
displayGroup = displayio.Group(scale=1)
display.show(displayGroup)

class SpriteText:
    font_sheet, bwPalette = adafruit_imageload.load("lib/font.bmp",bitmap=displayio.Bitmap,palette=displayio.Palette)
    def __init__(self, x, y, str):
        self.group = displayio.Group()
        self.group.x = x
        self.group.y = y
        self.str = str
        self.array=[]
        displayGroup.append(self.group)
        for i in range(len(str)):
            self.array.append(displayio.TileGrid(self.font_sheet, pixel_shader=self.bwPalette,width = 1,height = 1,tile_width = 8,tile_height = 8))
            self.group.append(self.array[i])
            self.array[i].x = i * 7
            self.array[i].y = 0
            self.array[i][0] = ord(str[i]) - 32
    def showValue(self, value):
        tmp = value
        for s in reversed(self.array):
            s[0] = 16 + tmp % 10
            tmp = int(tmp/10)
    def delete(self):
        for g in self.group:
            self.group.pop()
            self.array.pop()
            
    # define destructor...
