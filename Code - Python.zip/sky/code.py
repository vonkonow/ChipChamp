# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
# This game is a work in progress, but implements the basic controlls for a 
# tower jumping game. 
#
# 2023-05-21 * implemented the basic jumping controll, allowing height control
#              (depending on key press time) and double jump to change direction.
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                           # game hw config (keys & display)
import displayio                    # display module
import adafruit_imageload           # import .bmp sprite map
import time                         # delay


x_max, y_max = 2, 8
level = [
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ','x',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ','x',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ','x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '],
    ['x',' ',' ',' ','x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
    ['x',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','x',' ',' '],
]
spr = [' ', 'x', '+', '.', '$', '*', '#', ' ']

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# Main function
def main():
    global playField

    # Load sprite_sheets from file
    sprite_sheet, palette = adafruit_imageload.load("sky/sky_sprite.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette)

    class Sprite:
        def __init__(self, grp, sheet, palette):
            self.s = displayio.TileGrid(
                sheet, pixel_shader=palette, width=1, height=1, tile_width=8, tile_height=8)
            grp.append(self.s)

        def setSprite(self, t):
            self.s[0] = t

        def getSprite(self):
            return (self.s[0])

        def setPos(self, x, y):
            self.s.x = x
            self.s.y = y

    class Field:
        def __init__(self):
            self.grp = displayio.Group()
            hw.displayGroup.append(self.grp)
            self.array = []
            for i in range(x_max * y_max):
                s = Sprite(self.grp, sprite_sheet, palette)
                s.setPos((i % x_max) * 8, int(i / x_max) * 8)
                self.array.append(s)
            self.reset(1)

        def setBlock(self, x, y, block):
            self.array[y * x_max + x].setSprite(block)

        def getBlock(self, x, y):
            return (self.array[y * x_max + x].getSprite())

        def refresh(self):
            for s in self.array:
                s.setSprite(s.getSprite())
            
        def reset(self, spriteId):
            for s in self.array:
                s.setSprite(spriteId)

    # instantiate classes
    player = Sprite(hw.displayGroup, sprite_sheet, palette)
    player.setSprite(1)
#    playField = Field()                             # Playfield (dropped Tetrominoes)
    walls = [(10,0),(10,8),(10,16),(10,32),(60,100),(60,108),(60,80)]
    wallSprite = []
    
    for i,w in enumerate(walls):
        wallSprite.append(Sprite(hw.displayGroup, sprite_sheet, palette))
        wallSprite[i].setSprite(2)
        wallSprite[i].setPos(w[0], w[1])


# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

    # init game
    frameCounter = 0
    px=20
    py=120
    pd= 1
    pdx = 0
    pdy = 0
    jump = 0
    aHold = 0
    aCount = 0
    
#    hw.display.refresh()   
    # main game loop
    while True:    
        if hw.key('A'):
            aHold += 1
            if aHold == 1:  # New press
                jump = 1
                aCount += 1
                if aCount == 2: # Change direction mid-air
                    pd *= -1
            if aCount < 3 and aHold < 30: # Jump higher if pressed
                pdy=-1
                pdx=1
        else:
            aHold = 0 # Key released, reset count

        if jump:
            pdy += .1
            px = int(px+pd*pdx)
            py = int(py+pdy)
        else: 
            aCount = 0

        if py > 120:
            py=120
            jump = 0

        if px > 152:
            px = 152
            pd = -1
            jump = 0

        if px < 0:
            px = 0
            pd = 1
            jump = 0
        
        player.setPos(px,py)

        for w in wallSprite:
            if collision(w.s, player.s):
                jump = 0
                pd *= -1
                while collision(w.s, player.s):
                    px += pd
                    player.setPos(px,py)
                
        if jump == 0:
            aCount = 0        
             
#        for cy, row in enumerate(level):
#            for cx, cell in enumerate(row):
#                playField.setBlock(cx,cy,spr.index(cell))
            # print(''.join(row))

        
        # Pause menu
        if hw.key_new('U'):
            row1 = hw.SpriteText(20, 40, "Paused")
            row2 = hw.SpriteText(20, 50, "  Resume")
            row3 = hw.SpriteText(20, 60, "  Exit")
            sel = hw.SpriteText(20, 50, ">")
            pos = 0
            while True:
                sel.group.y = 50 + pos * 10
                hw.display.refresh()
                if hw.key_new('D') and pos < 1:
                    pos += 1
                    print(pos)
                if hw.key_new('U') and pos > 0:
                    pos -= 1
                    print(pos)
                if hw.key_new('A') or hw.key_new('B'):
                    if pos == 0:
                        break                   # resume game
                    else:       
                        return()                # exit game
            for i in range(4):                  # remove menu
                hw.displayGroup.pop()
            playField.refresh()
            hw.display.refresh()

        frameCounter += 1
        hw.display.refresh(target_frames_per_second=80)

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# collision detection (between two tile grid objects)
def collision(a,b):
    y = (a.y - b.y)
    if y > -16 and y < 16:
        x = (a.x - b.x)
        if x > -16 and x < 16:
            print(str(x)+ "," + str(y))
            xt = x
            if xt < 0:
                xt *= -1
            yt = y
            if yt < 0:
                yt *= -1
            if xt-yt > 0:
                print("x")
            return 1
    return 0

if __name__ == "__main__":
    main()
