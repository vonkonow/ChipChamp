# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#
#           ********** ******** ********** *******    **   ********
#          /////**/// /**///// /////**/// /**////**  /**  **//////
#              /**    /**          /**    /**   /**  /** /**
#              /**    /*******     /**    /*******   /** /*********
#              /**    /**////      /**    /**///**   /** ////////**
#              /**    /**          /**    /**  //**  /**        /**
#              /**    /********    /**    /**   //** /**  ********
#              //     ////////     //     //     //  //  ////////
#                                A circuitpython demonstrator game.
#
# Description: A Tetris implementation written to be fun to play
# Knowledge level: Medium
#
# This game uses displayIO that handles sprites as objects that can be moved
# around instead of clearing and redrawing the display buffer for each frame.
#   A sprite object is a tileGrid (a defined area of a bitmap/ spritemap).
#   The following parameters are used:
#   * spriteExample.x = 30 # x position of the object.
#   * spriteExample.y = 80 # y position of the object.
#   * spriteExample[0] = 2 # sprite index of the tile grid from the bitmap.
#
# TODO:
# * implement multi player over Wi-Fi (fix ESP-NOW restart without crash)
# * non volatile high score?
# * sound would be nice...
#
# DONE:
# 2023-05-30  * added B game mode, level and height
# 2023-04-29  * replaced global variables with classes...
# 2023-04-15  * added shadow tetrominoe
#             * added Delayed Auto Shift
# 2023-04-04  * ported code from c to circuitpython
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                           # game hw config (keys & display)
import displayio                    # display module
import adafruit_imageload           # import .bmp sprite map
import time                         # delay
import random                       # random
import board                        # used for music setup
import pwmio                        # used for music playback
#import espnow                       # wireless multiplayer


# Static values
MAX_COL = 10                        #
MAX_ROW = 18                        #
POINTS = [0, 40, 100, 300, 1200]    #
SPEED = [53, 49, 45, 41, 37, 33, 28, 22, 17, 11, 10, 9, 8, 7, 6, 6, 5, 5, 4, 4, 3]
DAS_F = 23                          # frames until first Delay Auto Shift
DAS_R = 9                           # frames until repeat Delay Auto Shift
MUSIC = False                       # experiment with music, playback is uneven and needs timer interrupt

# Music using 4 channel pwm
tetris = "0,0,76, 0,1,40, 0,2,71, 11,1,52, 8,0,0, 0,2,0, 3,0,71, 0,1,40, 0,2,68, 11,0,72, 0,1,52, 0,2,69, 11,0,74, 0,1,40, 0,2,71, 11,1,52, 0,2,76, 5,2,74, 2,0,0, 3,0,72, 0,1,40,0,2,69,11,0,71,0,1,52,0,2,68,11,0,69,0,1,45,0,2,64,11,1,57,8,0,0,0,2,0,3,0,69,0,1,45,11,0,72,0,1,57,0,2,69,11,0,76,0,1,45,0,2,72,11,1,57,8,0,0,0,2,0,3,0,74,0,1,45,0,2,71,11,0,72,0,1,57,0,2,69,11,0,71,0,1,44,0,2,68,5,2,68,5,1,56,0,2,64,11,1,44,0,2,68,8,0,0,3,0,72,0,1,56,0,2,69,11,0,74,0,1,40,0,2,71,11,1,52,8,0,0,0,2,0,3,0,76,0,1,40,0,2,72,11,1,52,8,0,0,0,2,0,3,0,72,0,1,45,0,2,69,11,1,57,8,0,0,0,2,0,3,0,69,0,1,45,0,2,64,11,1,57,8,0,0,0,2,0,3,0,69,0,1,45,0,2,64,11,1,57,8,0,0,0,2,0,3,1,47,11,1,48,11,1,50,0,2,50,11,0,74,0,1,38,0,2,65,20,0,0,0,1,0,0,2,0,4,0,77,0,1,38,0,2,69,11,0,81,0,2,72,8,1,0,3,1,38,0,2,72,5,2,72,2,0,0,3,0,79,0,1,45,0,2,71,11,0,77,0,1,41,0,2,69,11,0,76,0,1,36,0,2,67,11,1,48,20,0,0,0,1,0,0,2,0,4,0,72,0,1,48,0,2,64,11,0,76,0,1,36,0,2,67,11,1,43,0,2,69,5,2,67,2,0,0,3,0,74,0,1,43,0,2,65,11,0,72,0,2,64,8,1,0,3,0,71,0,1,47,0,2,68,11,1,59,0,2,64,8,0,0,3,0,71,0,2,68,8,1,0,3,0,72,0,1,59,0,2,69,11,0,74,0,2,71,8,1,0,3,1,52,0,2,68,8,0,0,3,0,76,0,2,72,8,1,0,3,1,56,0,2,68,8,0,0,3,0,72,0,1,45,0,2,69,5,2,72,5,1,52,0,2,69,8,0,0,3,0,69,0,1,45,0,2,64,11,1,52,8,0,0,0,2,0,3,0,69,0,1,45,0,2,64,20,0,0,0,1,0,0,2,0,28,0,76,0,1,40,0,2,71,11,1,52,8,0,0,0,2,0,3,0,71,0,1,40,0,2,68,11,0,72,0,1,52,0,2,69,11,0,74,0,1,40,0,2,71,11,1,52,0,2,76,5,2,74,2,0,0,3,0,72,0,1,40,0,2,69,11,0,71,0,1,52,0,2,68,11,0,69,0,1,45,0,2,64,11,1,57,8,0,0,0,2,0,3,0,69,0,1,45,11,0,72,0,1,57,0,2,69,11,0,76,0,1,45,0,2,72,11,1,57,8,0,0,0,2,0,3,0,74,0,1,45,0,2,71,11,0,72,0,1,57,0,2,69,11,0,71,0,1,44,0,2,68,5,2,68,5,1,56,0,2,64,11,1,44,0,2,68,8,0,0,3,0,72,0,1,56,0,2,69,11,0,74,0,1,40,0,2,71,11,1,52,8,0,0,0,2,0,3,0,76,0,1,40,0,2,72,11,1,52,8,0,0,0,2,0,3,0,72,0,1,45,0,2,69,11,1,57,8,0,0,0,2,0,3,0,69,0,1,45,0,2,64,11,1,57,8,0,0,0,2,0,3,0,69,0,1,45,0,2,64,11,1,57,8,0,0,0,2,0,3,1,47,11,1,48,11,1,50,0,2,50,11,0,74,0,1,38,0,2,65,20,0,0,0,1,0,0,2,0,4,0,77,0,1,38,0,2,69,11,0,81,0,2,72,8,1,0,3,1,38,0,2,72,5,2,72,2,0,0,3,0,79,0,1,45,0,2,71,11,0,77,0,1,41,0,2,69,11,0,76,0,1,36,0,2,67,11,1,48,20,0,0,0,1,0,0,2,0,4,0,72,0,1,48,0,2,64,11,0,76,0,1,36,0,2,67,11,1,43,0,2,69,5,2,67,2,0,0,3,0,74,0,1,43,0,2,65,11,0,72,0,2,64,8,1,0,3,0,71,0,1,47,0,2,68,11,1,59,0,2,64,8,0,0,3,0,71,0,2,68,8,1,0,3,0,72,0,1,59,0,2,69,11,0,74,0,2,71,8,1,0,3,1,52,0,2,68,8,0,0,3,0,76,0,2,72,8,1,0,3,1,56,0,2,68,8,0,0,3,0,72,0,1,45,0,2,69,5,2,72,5,1,52,0,2,69,8,0,0,3,0,69,0,1,45,0,2,64,11,1,52,8,0,0,0,2,0,3,0,69,0,1,45,0,2,64,20,0,0,0,1,0,0,2,0,28,0,52,0,1,57,0,2,48,11,1,64,11,1,57,11,1,64,11,0,48,0,1,57,0,2,45,11,1,64,11,1,57,11,1,64,11,0,50,0,1,56,0,2,47,11,1,64,11,1,56,11,1,64,11,0,47,0,1,56,0,2,44,11,1,64,11,1,56,11,1,64,11,0,48,0,1,57,0,2,45,11,1,64,11,1,57,11,1,64,11,0,45,0,1,57,0,2,40,11,1,64,11,1,57,11,1,64,11,0,44,0,1,56,11,1,64,11,1,56,11,1,64,11,1,0,0,2,47,20,2,0,22,0,0,6,0,52,0,1,57,0,2,48,11,1,64,11,1,57,11,1,64,11,0,48,0,1,57,0,2,45,11,1,64,11,1,57,11,1,64,11,0,50,0,1,56,0,2,47,11,1,64,11,1,56,11,1,64,11,0,47,0,1,56,0,2,44,11,1,64,11,1,56,11,1,64,6,0,0,0,2,0,5,0,48,0,1,57,0,2,45,11,1,64,8,0,0,0,2,0,3,0,52,0,1,57,0,2,48,11,1,64,8,0,0,0,2,0,3,0,57,0,1,57,0,2,52,11,1,64,11,1,57,11,1,64,6,0,0,0,2,0,5,0,56,0,1,56,0,2,50,11,1,64,11,1,56,11,1,64,6,0,0,0,2,0,5,1,0"
frequency = "8,9,9,10,10,11,12,12,13,14,15,15,16,17,18,19,21,22,23,25,26,28,29,31,33,35,37,39,41,44,46,49,52,55,58,62,65,69,73,78,82,87,93,98,104,110,117,123,131,139,147,156,165,175,185,196,208,220,233,247,262,277,294,311,330,349,370,392,415,440,466,494,523,554,587,622,659,698,740,784,831,880,932,988,1047,1109,1175,1245,1319,1397,1480,1568,1661,1760,1865,1976,2093,2217,2349,2489,2637,2794,2960,3136,3322,3520,3729,3951,4186,4435,4699,4978,5274,5588,5920,6272,6645,7040,7459,7902,8372,8870,9397,9956,10548,11175,11840,12544"
song = [int(n) for n in tetris.split(',')]
freq = [int(n) for n in frequency.split(',')]
pwm0 = pwmio.PWMOut(board.IO16, duty_cycle=0, frequency=440, variable_frequency=True)
pwm1 = pwmio.PWMOut(board.IO17, duty_cycle=0, frequency=440, variable_frequency=True)
pwm2 = pwmio.PWMOut(board.IO18, duty_cycle=0, frequency=440, variable_frequency=True)
pwm3 = pwmio.PWMOut(board.IO21, duty_cycle=0, frequency=440, variable_frequency=True)
pwm = [pwm0,pwm1,pwm2,pwm3]

# rotation matrix (tetrominoes) in semi readable form (from GBA)
#
# I=1  J=2  L=3  O=4  S=5  T=6  Z=7
# 0000 0000 0000 0000 0000 0000 0000
# 0000 2220 3330 0440 0550 6660 7700
# 1111 0020 3000 0440 5500 0600 0770
# 0000 0000 0000 0000 0000 0000 0000
#
# 0100 0200 3300 0000 5000 0600 0700
# 0100 0200 0300 0440 5500 6600 7700
# 0100 2200 0300 0440 0500 0600 7000
# 0100 0000 0000 0000 0000 0000 0000
#
# 0000 2000 0030 0000 0000 0600 0000
# 0000 2220 3330 0440 0550 6660 7700
# 1111 0000 0000 0440 5500 0000 0770
# 0000 0000 0000 0000 0000 0000 0000
#
# 0100 0220 0300 0000 5000 0600 0700
# 0100 0200 0300 0440 5500 0660 7700
# 0100 0200 0330 0440 0500 0600 7000
# 0100 0000 0000 0000 0000 0000 0000
#
tetrominoe = [
  [0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0, 0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0, 0,0,0,0,0,0,0,0,1,1,1,1,0,0,0,0, 0,1,0,0,0,1,0,0,0,1,0,0,0,1,0,0],
  [0,0,0,0,2,2,2,0,0,0,2,0,0,0,0,0, 0,2,0,0,0,2,0,0,2,2,0,0,0,0,0,0, 2,0,0,0,2,2,2,0,0,0,0,0,0,0,0,0, 0,2,2,0,0,2,0,0,0,2,0,0,0,0,0,0],
  [0,0,0,0,3,3,3,0,3,0,0,0,0,0,0,0, 3,3,0,0,0,3,0,0,0,3,0,0,0,0,0,0, 0,0,3,0,3,3,3,0,0,0,0,0,0,0,0,0, 0,3,0,0,0,3,0,0,0,3,3,0,0,0,0,0],
  [0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0, 0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0, 0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0, 0,0,0,0,0,4,4,0,0,4,4,0,0,0,0,0],
  [0,0,0,0,0,5,5,0,5,5,0,0,0,0,0,0, 5,0,0,0,5,5,0,0,0,5,0,0,0,0,0,0, 0,0,0,0,0,5,5,0,5,5,0,0,0,0,0,0, 5,0,0,0,5,5,0,0,0,5,0,0,0,0,0,0],
  [0,0,0,0,6,6,6,0,0,6,0,0,0,0,0,0, 0,6,0,0,6,6,0,0,0,6,0,0,0,0,0,0, 0,6,0,0,6,6,6,0,0,0,0,0,0,0,0,0, 0,6,0,0,0,6,6,0,0,6,0,0,0,0,0,0],
  [0,0,0,0,7,7,0,0,0,7,7,0,0,0,0,0, 0,7,0,0,7,7,0,0,7,0,0,0,0,0,0,0, 0,0,0,0,7,7,0,0,0,7,7,0,0,0,0,0, 0,7,0,0,7,7,0,0,7,0,0,0,0,0,0,0]]


# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# Main function
def main():
    global playField

    # Load sprite_sheets from file
    # path=__file__[0:__file__.rfind('/')+1]
    sprite_sheet, palette = adafruit_imageload.load(
        "tetris/tetris_sprite.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette)
    palette.make_transparent(0)

    # key=hw.key()

    class key:
        def __init__(self, key):
            self.key = key
            self.prev = 0

        def test(self):
            self.prev = self.prev + 1 if not self.key.value else 0
            if self.prev == 1 or (self.prev > DAS_F and self.prev % DAS_R == 0):
                return True
            return False

    class Sprite:
        def __init__(self, grp, sheet, palette):
            self.s = displayio.TileGrid(
                sheet, pixel_shader=palette, width=1, height=1, tile_width=8, tile_height=8)
            grp.append(self.s)

        def setSprite(self, t):
            self.s[0] = t

        def getSprite(self):
            return (self.s[0])

        def setPos(self, x, y):
            self.s.x = x
            self.s.y = y

    class Shape:
        def __init__(self):
            self.grp = displayio.Group()
            hw.displayGroup.append(self.grp)
            self.id = 0
            self.x = 3
            self.y = -2
            self.r = 0
            self.grp.x = 16 + self.x * 7
            self.grp.y = self.y * 7
            self.array = []
            for i in range(16):
                s = Sprite(self.grp, sprite_sheet, palette)
                s.setPos(int(i % 4) * 7, int(i/4) * 7)
                self.array.append(s)

        def update(self, rot, block):
            for i in range(16):
                self.array[i].s[0] = block if tetrominoe[self.id][i + rot * 16] != 0 else 0

        def drop(self, y, field):
            if field.testPos(plr.id, plr.x, y, plr.r):
                while field.testPos(plr.id, plr.x, y, plr.r):
                    y += 1
                self.grp.x = plr.grp.x
                self.grp.y = (y - 1) * 7
            else:
                self.grp.y = -100

    class Field:
        def __init__(self):
            self.array = []
            for i in range(MAX_ROW * MAX_COL):
                s = Sprite(hw.displayGroup, sprite_sheet, palette)
                s.setPos(16 + (i % MAX_COL) * 7, int(i / MAX_COL) * 7)
                self.array.append(s)
            self.reset(0)

        def setBlock(self, x, y, block):
            self.array[y * MAX_COL + x].setSprite(block)

        def getBlock(self, x, y):
            return (self.array[y * MAX_COL + x].getSprite())

        def testPos(self, id, x, y, r):
            for cy in range(4):
                for cx in range(4):
                    block = tetrominoe[id][r*16 + cy*4 + cx]
                    if block != 0 and (x+cx < 0 or x+cx >= MAX_COL):
                        return 0        # block is outside walls
                    if block != 0 and y+cy > 0:
                        if y+cy >= MAX_ROW:
                            return 0    # block is below field
                        if self.getBlock(x+cx, y+cy) != 0:
                            return 0    # block interferes with previous tetrominoes (abort)
            return 1    # tetrominoe movement is ok (return true)

        def trash(self, height):
            for i in range(height):
                for cy in range(1, 18, 1):
                    for cx in range(MAX_COL):
                        self.setBlock(cx, cy-1, self.getBlock(cx, cy))
                for cx in range(MAX_COL):
                    r = random.randint(0, 10)
                    if r > 7:
                        r = 0
                    self.setBlock(cx, 17, r)

        def refresh(self):
            for s in self.array:
                s.setSprite(s.getSprite())

        def reset(self, spriteId):
            for s in self.array:
                s.setSprite(spriteId)

    class Wall:
        def __init__(self, x):
            self.grp = displayio.Group()
            hw.displayGroup.append(self.grp)
            self.array = []
            for i in range(21):
                s = Sprite(self.grp, sprite_sheet, palette)
                s.setPos(x, i * 6)
                s.setSprite(8)
                self.array.append(s)

    # instantiate classes
    keyU = key(hw.KEY_U)                            # Key up with Delay Auto Shift
    keyD = key(hw.KEY_D)                            # Down...
    keyR = key(hw.KEY_R)                            #
    keyL = key(hw.KEY_L)                            #
    keyA = key(hw.KEY_A)                            #
    keyB = key(hw.KEY_B)                            #

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

    # init game
    score = 0
    lines = 0
    level = 0
    startLevel = 0
    startHeight = 0
    gameMode = 'A'
    frameCounter = 0
    playField = Field()                             # Playfield (dropped Tetrominoes)
    tick, songPos = 0,0

    # Start menu
    row0  = hw.SpriteText(19, 20, "Settings")
    row1  = hw.SpriteText(22, 40, " Start")
    row2  = hw.SpriteText(32, 50, " Mode")
    row2a = hw.SpriteText(80, 50, " A")
    row3  = hw.SpriteText(32, 60, " Level")
    row3a = hw.SpriteText(80, 60, " 0")
    row4  = hw.SpriteText(32, 70, " Height")
    row4a = hw.SpriteText(80, 70, " 0")
    row5  = hw.SpriteText(22, 80, " Exit")
    sel   = hw.SpriteText(19, 40, ">")
    pos = 0
    while True:
        if keyD.test(): pos += 1
        if pos > 4: pos = 0
        if keyU.test(): pos -= 1
        if pos < 0: pos = 4
        menuAB = 0
        if keyA.test() or keyR.test():
            menuAB = 1
            while not hw.KEY_A.value and not hw.KEY_R.value:   # wait until key is released...
                time.sleep(0.02)
        if keyB.test() or keyL.test():
            menuAB = -1
            while not hw.KEY_B.value and not hw.KEY_L.value:   # wait until key is released...
                time.sleep(0.02)
        if menuAB != 0:
            if pos == 0:    # Start
                break
            if pos == 1:    # mode
                gameMode = "A" if gameMode == "B" else "B"
            if pos == 2:    # level
                startLevel += menuAB
                if startLevel < 0: startLevel = 0
                if startLevel > 9: startLevel = 9
            if pos == 3:    # height
                startHeight += menuAB
                if startHeight < 0: startHeight = 0
                if startHeight > 5: startHeight = 5
            if pos == 4:    # exit game
                return()
        sel.group.y = 40 + pos * 10
        row2a.array[1][0]=ord(gameMode)-32
        row3a.array[1][0]=startLevel+48-32
        row4a.array[1][0]=startHeight+48-32
        hw.display.refresh()
    for i in range(10):      # remove menu
        hw.displayGroup.pop()


    # prepare game
    if gameMode == "B":
        lines = 25
    playField.trash(startHeight*2)
    playField.refresh()
    hw.display.refresh()
    shadow = Shape()                                # Shadow Tetrominoe
    plr = Shape()                                   # Player (falling) tetrominoe
    plr.id = random.randint(0, 6)
    plr.update(plr.r, plr.id + 1)
    shadow.id = plr.id
    shadow.update(plr.r, 10)
    shadow.drop(15, playField)
    wall1 = Wall(8)                                 # Left brick column
    wall2 = Wall(87)                                # Right brick column
    scrtxt = hw.SpriteText(110, 5, "SCORE")         # Score text
    scr = hw.SpriteText(110, 15, "000000")          # Score value
    nxttxt = hw.SpriteText(110, 30, "NEXT")         # Next text
    nxt = Shape()                                   # Next Tetrominoe
    nxt.grp.x = 120                                 #
    nxt.grp.y = 40                                  #
    nxt.id = random.randint(0, 6)
    nxt.update(0, nxt.id + 1)
    lvltxt = hw.SpriteText(110, 70, "LEVEL")        #
    lvl = hw.SpriteText(110, 80, "00")              #
    lnstxt = hw.SpriteText(110, 100, "LINES")       #
    lns = hw.SpriteText(110, 110, "0000")           #
    lns.showValue(lines)

#    try:
#        espnow.delete()
#    except:
#        pass
#    e = espnow.ESPNow()
#    e.peers.append(espnow.Peer(mac=b'\x48\x27\xe2\x51\xd8\x76'))   # yellow
#    e.peers.append(espnow.Peer(mac=b'\x48\x27\xe2\x55\xfb\xf4'))   # cyan

    # main game loop
    while True:
#        if e:
#            packet = e.read()
#            if packet.msg[0] != 101: # not end
#                print(packet.msg[0]-48)
#                playField.trash(packet.msg[0]-48)
#                hw.display.refresh()
#                time.sleep(0.5)

        # Move right
        if keyR.test() and playField.testPos(plr.id, plr.x+1, plr.y, plr.r):
            plr.x += 1
            plr.grp.x = 16 + plr.x * 7

        # Move left
        if keyL.test() and playField.testPos(plr.id, plr.x-1, plr.y, plr.r):
            plr.x -= 1
            plr.grp.x = 16 + plr.x * 7

        # Rotate ClockWise
        if keyA.test():
            tmp = plr.r + 1
            if tmp > 3:
                tmp = 0
            if playField.testPos(plr.id, plr.x, plr.y, tmp):
                plr.r = tmp
                plr.update(plr.r, plr.id+1)
                shadow.update(plr.r, 10)

        # Rotate CounterClockWise
        if keyB.test():
            tmp = plr.r - 1
            if tmp < 0:
                tmp = 3
            if playField.testPos(plr.id, plr.x, plr.y, tmp):
                plr.r = tmp
                plr.update(plr.r, plr.id+1)
                shadow.update(plr.r, 10)

        # Soft drop
        if keyD.test() and playField.testPos(plr.id, plr.x, plr.y+1, plr.r):
            plr.y += 1
            plr.grp.y = plr.y * 7

        # Pause menu
        if keyU.test():
            black_bitmap = displayio.Bitmap(70, 128, 1)
            black_palette = displayio.Palette(1)
            black_sprite = displayio.TileGrid(black_bitmap, pixel_shader=black_palette, x=16, y=0)
            hw.displayGroup.append(black_sprite)
#            e.send(b'2')
#            e.send(b'end')
            row1  = hw.SpriteText(20, 30, "Paused")
            row2  = hw.SpriteText(22, 50, " Resume")
            row6  = hw.SpriteText(22, 60, " Exit")
            sel   = hw.SpriteText(19, 50, ">")
            pos = 0
            startHeight = 0
            while True:
                if keyD.test(): pos += 1
                if pos > 1: pos = 0
                if keyU.test(): pos -= 1
                if pos < 0: pos = 1
                if keyA.test() or keyB.test():
                    while not hw.KEY_A.value and not hw.KEY_B.value:   # wait until key is released...
                        time.sleep(0.02)
                    if pos == 0:    # resume game
                        break
                    if pos == 1:    # exit game
                        return()
                sel.group.y = 50 + pos * 10
                hw.display.refresh()
            for i in range(5):      # remove menu + bg
                hw.displayGroup.pop()
            playField.refresh()
            hw.display.refresh()

        # Auto drop
        if frameCounter % SPEED[startLevel] == 0:
            if playField.testPos(plr.id, plr.x, plr.y+1, plr.r):
                # free to move down tetrominoe
                plr.y += 1
                plr.grp.y = plr.y * 7
            else:
                # save tetrominoe on field
                for cy in range(4):
                    for cx in range(4):
                        block = tetrominoe[plr.id][plr.r*16 + cy*4 + cx]
                        if block != 0 and cy+plr.y >= 0:
                            playField.setBlock(plr.x+cx, plr.y+cy, block)

                # find full rows, remove and move down rows above
                cRow = 0
                for cy in range(17, 0, -1):
                    i = 0
                    for cx in range(MAX_COL):
                        playField.setBlock(
                            cx, cy+cRow, playField.getBlock(cx, cy))
                        if playField.getBlock(cx, cy) != 0:
                            i += 1
                        if cRow > 0:
                            playField.setBlock(cx, cy, 0)
                    if i == MAX_COL:
                        cRow += 1
                        if gameMode == "A":
                            lines += 1
                        else:
                            lines -= 1
                            if lines <= 0:
                                gameOver = hw.SpriteText(16, 62, "WINNER!!!")
                                playField.reset(10)
                                hw.display.refresh()
                                time.sleep(3)
                                hw.displayGroup.pop()

                                # Reset game settings
                                frameCounter = 0
                                score = 0
                                lines = 0 if gameMode == "A" else 25
                                level = 0
                                plr.id = random.randint(0, 6)
                                shadow.id = plr.id
                                nxt.id = random.randint(0, 6)
                                playField.reset(0)
                                playField.trash(startHeight*2)
                                playField.refresh()
                                time.sleep(1)
#                if cRow > 1:
#                    e.send(str(cRow-1))
#                    e.send(b'end')

                # level handling
                # *** add start count multiplier (start at level4 stays 50 lines)
                level = int(lines / 10)
                if level > len(SPEED):
                    level = len(SPEED)

                # game over?
                if (plr.y < 0):
                    gameOver = hw.SpriteText(16, 62, "Game Over!")
                    playField.reset(10)
                    hw.display.refresh()
                    time.sleep(3)
                    hw.displayGroup.pop()
                    # Reset game settings
                    frameCounter = 0
                    score = 0
                    lines = 0 if gameMode == "A" else 25
                    level = 0
                    plr.id = random.randint(0, 6)
                    shadow.id = plr.id
                    nxt.id = random.randint(0, 6)
                    playField.reset(0)
                    playField.trash(startHeight*2)
                    playField.refresh()
                    time.sleep(1)

                # update score, level, lines
                if startLevel > level:
                    score += POINTS[cRow] * (startLevel + 1)
                    lvl.showValue(startLevel)
                else:
                    score += POINTS[cRow] * (level + 1)
                    lvl.showValue(level)
                scr.showValue(score)
                lns.showValue(lines)

                # init next tetrominoe
                plr.id = nxt.id
                plr.x = 3
                plr.y = -2
                plr.r = 0
                plr.grp.x = 16 + plr.x * 7
                plr.grp.y = plr.y * 7
                plr.update(plr.r, plr.id + 1)
                shadow.id = plr.id
                shadow.update(plr.r, 10)
                nxt.id = random.randint(0, 6)
                nxt.update(0, nxt.id + 1)

        shadow.drop(plr.y+1, playField)

        frameCounter += 1
        hw.display.refresh(target_frames_per_second=60)

        # update music (tick, audio channel, frequency)
        if MUSIC:
            while (tick == song[songPos]):
                if song[songPos+2] == 0:
                    pwm[song[songPos+1]].duty_cycle = 0
                else:
                    pwm[song[songPos+1]].duty_cycle = 32768 # 50%
                    pwm[song[songPos+1]].frequency = freq[song[songPos+2]]
                tick = 0
                songPos += 3
                if songPos >= len(song):
                    songPos = 0
            tick += 1

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

if __name__ == "__main__":
    main()
