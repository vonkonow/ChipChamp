
________/\\\\\\\\\__/\\\____________________________________/\\\\\\\\\__/\\\__________________________________________________________        
 _____/\\\////////__\/\\\_________________________________/\\\////////__\/\\\__________________________________________________________       
  ___/\\\/___________\/\\\__________/\\\___/\\\\\\\\\____/\\\/___________\/\\\______________________________________________/\\\\\\\\\__      
   __/\\\_____________\/\\\_________\///___/\\\/////\\\__/\\\_____________\/\\\__________/\\\\\\\\\_______/\\\\\__/\\\\\____/\\\/////\\\_     
    _\/\\\_____________\/\\\\\\\\\\___/\\\_\/\\\\\\\\\\__\/\\\_____________\/\\\\\\\\\\__\////////\\\____/\\\///\\\\\///\\\_\/\\\\\\\\\\__    
     _\//\\\____________\/\\\/////\\\_\/\\\_\/\\\//////___\//\\\____________\/\\\/////\\\___/\\\\\\\\\\__\/\\\_\//\\\__\/\\\_\/\\\//////___   
      __\///\\\__________\/\\\___\/\\\_\/\\\_\/\\\__________\///\\\__________\/\\\___\/\\\__/\\\/////\\\__\/\\\__\/\\\__\/\\\_\/\\\_________  
       ____\////\\\\\\\\\_\/\\\___\/\\\_\/\\\_\/\\\____________\////\\\\\\\\\_\/\\\___\/\\\_\//\\\\\\\\/\\_\/\\\__\/\\\__\/\\\_\/\\\_________ 
        _______\/////////__\///____\///__\///__\///________________\/////////__\///____\///___\////////\//__\///___\///___\///__\///__________


This folder contains example code in Circuit Python for the ChipChamp gaming console.

The examples can easily be edited in any text editor (personally I prefer VS Code, with the serial terminal module, but MU is also a great choice)

Installation:
1 ChipChamp needs to have Circuit Python installed, see details here: https://circuitpython.org/board/lolin_s2_mini/
2 Connect ChipChamp to a computer and it will appear as a USB memory.
  (if it doesn't, ensure that Circuit python is installed and that you have a USB-C cable with data wires, missing in some charging cables).
3 Copy all files and folders in this directory to the root of ChipChamp. It should automatically reset and load code.py.

Detailed instructions for how you buid your own ChipChamp can be found here:
https://vonkonow.com/chipchamp/

ChipChamp is open source under MIT License.
(attribution is optional, but always appreciated - Johan von Konow ;)