# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|
# ******************************************************************************
#
#       @@@@@@  @@@@@@  @@@  @@@  @@@@@@  @@@@@@@   @@@@@@  @@@ @@@ 
#      !@@     @@!  @@@ @@!  !@@ @@!  @@@ @@!  @@@ @@!  @@@ @@! !@@ 
#       !@@!!  @!@  !@! @!@@!@!  @!@  !@! @!@  !@! @!@!@!@!  !@!@!  
#          !:! !!:  !!! !!: :!!  !!:  !!! !!:  !!! !!:  !!!   !!:   
#      ::.: :   : :. :   :   :::  : :. :  :: :  :   :   : :   .:  
#                                A circuitpython demonstrator game.
#
# Description: A Sokoban implementation for ChipChamp.
# It can connect to a server over WiFi and download three new levels each day.
# ===> WiFi credentials needs to be specified in secrets.py <===
# Knowledge level: Easy to Medium
#
# TODO:
# * option to abort reconnect
# * bug fix rows shorter than 8
# * clear screen before WiFi
# * sound would be nice...
#
# DONE:
# 2023-06-04 
# * start menu and level select in pause menu
# * static level examples (3x3)
#
# 2023-05-20
# * ported code from javascript to circuitpython (thanks ChatGPT)
#
# This code is open source under MIT License.
# (attribution is optional, but always appreciated - Johan von Konow ;)
# ******************************************************************************

# Import python modules
import hw                           # game hw config (keys & display)
import displayio                    # display module
import adafruit_imageload           # import .bmp sprite map
import time                         # delay
import random                       # random
import ipaddress
import wifi
import socketpool
import ssl
import adafruit_requests

x_max, y_max, x_min, y_min = 8, 8, 0, 0
px, py = 0, 0
wall, player, goal, box, empty, player_goal, box_goal = '#', '@', '.', '$', ' ', '+', '*' 

preload = [
	[" ###### ,#  @   #,# #$##*#,# #  $ #,#.  .  #, ####  #,    #  #,     ## ","  ###   , #   #  ,#  # ## ,# * $  #,#. * #@#,# * *  #, # *  # ,  ####  ","  ##    , #  ##  , # $. # , #  $.# ,  #$. # ,  #@ #  ,  #  #  ,   ##   "],
	["##   ## ,   #.## , #.#$.##, # $  $ ,@$ #. # ,##.   $ ,  #$#.# ,  #     "," #    ##,##  * ##,  $**$  , $*..*  ,  *.+** ,  $**$  ,## *. ##, #    ##","     ###,  ###   , #  #   , # * * #,# *.*$@#,#  * * #, #     #,  ##### "],
	["  #####, #+ ...#, # $*$ #, ### ##,#  $   #,#    $,#  ##,#  ##","   ###,  #  ###, #  *,##@*.*,  * $ *,   ##  #,### #  #,     ###"," ######,#      #,#  ### #,#.   # #,#.#$$$ #,#.#@ $ #,#.  #  #, ### ##"]]

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

# Main function
def main():
	global playField, level

	# Load sprite_sheets from file
	sprite_sheet, palette = adafruit_imageload.load("sokoban/sokoban_sprite.bmp", bitmap=displayio.Bitmap, palette=displayio.Palette)

	class Sprite:
		def __init__(self, grp, sheet, palette):
			self.s = displayio.TileGrid(
				sheet, pixel_shader=palette, width=1, height=1, tile_width=16, tile_height=16)
			grp.append(self.s)

		def setSprite(self, t):
			self.s[0] = t

		def getSprite(self):
			return (self.s[0])

		def setPos(self, x, y):
			self.s.x = x
			self.s.y = y

	class Field:
		def __init__(self):
			self.array = []
			for i in range(x_max * y_max):
				s = Sprite(hw.displayGroup, sprite_sheet, palette)
				s.setPos((i % x_max) * 16 + 16, int(i / x_max) * 16)
				self.array.append(s)
			self.reset(7)

		def setBlock(self, x, y, block):
			self.array[y * x_max + x].setSprite(block)

		def getBlock(self, x, y):
			return (self.array[y * x_max + x].getSprite())

		def refresh(self):
			for s in self.array:
				s.setSprite(s.getSprite())

		def reset(self, spriteId):
			for s in self.array:
				s.setSprite(spriteId)

	# Create a black background
	black_sprite = displayio.TileGrid(displayio.Bitmap(160, 128, 1), pixel_shader=displayio.Palette(1), x=0, y=0)
	hw.displayGroup.append(black_sprite)

	# Start menu
	gameType = 0
	lvlType=["Short ","Medium","Long  "]
	row1 = hw.SpriteText(10, 20, "Game settings")
	row2 = hw.SpriteText(10, 40, "  Type: Short ")
	row3 = hw.SpriteText(10, 50, "  * Daily S WiFi")
	row4 = hw.SpriteText(10, 60, "  * Demo S1")
	row5 = hw.SpriteText(10, 70, "  * Demo S2")
	row6 = hw.SpriteText(10, 80, "  * Demo S3")
	row7 = hw.SpriteText(10, 90, "  Exit")
	sel = hw.SpriteText(10, 50, ">")
	pos = 1
	while True:
		sel.group.y = 40 + pos * 10
		hw.display.refresh()
		if hw.key_new('D') and pos < 5:
			pos += 1
		if hw.key_new('U') and pos > 0:
			pos -= 1
		if hw.key_new('A') or hw.key_new('B'):
			if pos == 0:
				if hw.key('A') and gameType < 2: gameType +=1
				if hw.key('B') and gameType > 0: gameType -=1
				for i in range(6):
					row2.array[8+i][0] = ord(lvlType[gameType][i])-32
				row3.array[10][0] = ord(lvlType[gameType][0])-32
				row4.array[9][0] = ord(lvlType[gameType][0])-32
				row5.array[9][0] = ord(lvlType[gameType][0])-32
				row6.array[9][0] = ord(lvlType[gameType][0])-32
			if pos == 1:
				request = connect()     # Establish WiFi connection
				if gameType == 0: level_import = getLevel(request, "http://vonkonow.com/sokoplay/short.php")    # Download Daily Short
				elif gameType == 1: level_import = getLevel(request, "http://vonkonow.com/sokoplay/medium.php") # Download Daily Medium
				else: level_import = getLevel(request, "http://vonkonow.com/sokoplay/long.php")                 # Download Daily Long
				break                   # start game
			if pos == 2 or pos == 3 or pos == 4:
				level_import = preload[gameType][pos-2]
				break
			elif pos == 5:
				return()                # exit game
	for i in range(8):                  # remove menu
		hw.displayGroup.pop()
	black_sprite[0]=0
	hw.display.refresh()

	# init game
	playField = Field()
	level = clean_level(level_import)
	show_level()
	print(level)
	frameCounter = 0

	# main game loop
	while True:
		# move player
		if hw.key_new('U'):
			move_player(0, -1)
		if hw.key_new('D'):
			move_player(0, 1)
		if hw.key_new('L'):
			move_player(-1, 0)
		if hw.key_new('R'):
			move_player(1, 0)

		# Pause menu
		if hw.key_new('A') or hw.key_new('B'):
			# Create a black background
			hw.displayGroup.append(displayio.TileGrid(displayio.Bitmap(160, 128, 1), pixel_shader=displayio.Palette(1), x=0, y=0))
			lvlType=["Short ","Medium","Long  "]
			row1 = hw.SpriteText(10, 20, "Paused")
			row2 = hw.SpriteText(10, 30, "  Type: Short ")
			row3 = hw.SpriteText(10, 40, "  Resume")
			row4 = hw.SpriteText(10, 50, "  * Daily S WiFi")
			row5 = hw.SpriteText(10, 60, "  * Demo S1")
			row6 = hw.SpriteText(10, 70, "  * Demo S2")
			row7 = hw.SpriteText(10, 80, "  * Demo S3")
			row8 = hw.SpriteText(10, 90, "  Exit")
			sel = hw.SpriteText(10, 40, ">")
			pos = 1
			# update type with selected gameType
			for i in range(6):
				row2.array[8+i][0] = ord(lvlType[gameType][i])-32
			row4.array[10][0] = ord(lvlType[gameType][0])-32
			row5.array[9][0] = ord(lvlType[gameType][0])-32
			row6.array[9][0] = ord(lvlType[gameType][0])-32
			row7.array[9][0] = ord(lvlType[gameType][0])-32
			while True:
				sel.group.y = 30 + pos * 10
				hw.display.refresh()
				if hw.key_new('D') and pos < 6:
					pos += 1
				if hw.key_new('U') and pos > 0:
					pos -= 1
				if hw.key_new('A') or hw.key_new('B'):
					if pos == 0:
						if hw.key('A') and gameType < 2: gameType +=1
						if hw.key('B') and gameType > 0: gameType -=1
						for i in range(6):
							row2.array[8+i][0] = ord(lvlType[gameType][i])-32
						row4.array[10][0] = ord(lvlType[gameType][0])-32
						row5.array[9][0] = ord(lvlType[gameType][0])-32
						row6.array[9][0] = ord(lvlType[gameType][0])-32
						row7.array[9][0] = ord(lvlType[gameType][0])-32
					if pos == 1:
						break
					if pos == 2:
						request = connect()     # Establish WiFi connection
						if gameType == 0: level_import = getLevel(request, "http://vonkonow.com/sokoplay/short.php")    # Download Daily Short
						elif gameType == 1: level_import = getLevel(request, "http://vonkonow.com/sokoplay/medium.php") # Download Daily Medium
						else: level_import = getLevel(request, "http://vonkonow.com/sokoplay/long.php")                 # Download Daily Long
						break                   # start game
					if pos == 3 or pos == 4 or pos == 5:
						level_import = preload[gameType][pos-3]
						break
					elif pos == 6:
						return()                # exit game
			for i in range(10):                 # remove menu
				hw.displayGroup.pop()
			black_sprite[0]=0
			level = clean_level(level_import)
			show_level() 
			hw.display.refresh()

		frameCounter += 1
		hw.display.refresh(target_frames_per_second=60)

# ------10|-------20|-------30|-------40|-------50|-------60|-------70|-------80|

def show_level():
	global px, py
	spr = ['_', '@', '+', '.', '$', '*', '#', ' ']
	for cy, row in enumerate(level):
		for cx, cell in enumerate(row):
			playField.setBlock(cx,cy,spr.index(cell))
			if cell == player or cell == player_goal:
				px, py = cx, cy
		# print(''.join(row))

def test_win():
	global gameOver
	for row in level:
		if goal in row or player_goal in row:
			return
	gameOver = hw.SpriteText(16, 62, "Winner!")
	hw.display.refresh(target_frames_per_second=60)
	hw.display.refresh(target_frames_per_second=60)
	time.sleep(3)
	gameOver.group.y = 255 # Outside active display area

def move_player(dx, dy):
	global px, py
	if px+dx >= x_max or px+dx < x_min or py+dy >= y_max or py+dy < y_min or level[py+dy][px+dx] == wall:
		print ("outside")
		return
	if level[py+dy][px+dx] in {box, box_goal}:
		if px+dx*2 >= x_max or px+dx*2 < x_min or py+dy*2 >= y_max or py+dy*2 < y_min or level[py+dy*2][px+dx*2] in {wall, box, box_goal}:
			print("stop")
			return
		if level[py+dy*2][px+dx*2] in {empty, None}:
			level[py+dy*2][px+dx*2] = box
		elif level[py+dy*2][px+dx*2] == goal:
			level[py+dy*2][px+dx*2] = box_goal
		if level[py+dy][px+dx] == box:
			level[py+dy][px+dx] = empty
		elif level[py+dy][px+dx] == box_goal:
			level[py+dy][px+dx] = goal
	if level[py+dy][px+dx] in {empty, None}:
		level[py+dy][px+dx] = player
	elif level[py+dy][px+dx] == goal:
		level[py+dy][px+dx] = player_goal
	if level[py][px] == player:
		level[py][px] = empty
	elif level[py][px] == player_goal:
		level[py][px] = goal
	px += dx
	py += dy
	show_level()
	test_win()

def connect():
	# Get wifi details and more from a secrets.py file
	try:
		from secrets import secrets
	except ImportError:
		print("WiFi secrets are kept in secrets.py, like this:")
		print("secrets = {")
		print("'ssid' : 'home_wifi_network',")
		print("'password' : 'wifi_password',")
		print(" }")
		raise
	print("Connecting to %s..."%secrets["ssid"])
	row1 = hw.SpriteText(10, 10, "Connecting")
	hw.display.refresh()
	connected = False
	retries = 0
	row2 = hw.SpriteText(10, 20, "Reconnecting")
	row2b = hw.SpriteText(100, 20, "..")
	while not connected:
		try:
			wifi.radio.connect(secrets["ssid"], secrets["password"])
		except:
			retries += 1
			print("Reconnecting...")
			row2b.showValue(retries)
			hw.display.refresh()
			time.sleep(.5)
		else:connected = True
	print("Connected to %s!"%secrets["ssid"])
	row3 = hw.SpriteText(10, 30, "Connected!")
	hw.display.refresh()
	print("my IP addr:", wifi.radio.ipv4_address)
	pool = socketpool.SocketPool(wifi.radio)
	for i in range(4):
		hw.displayGroup.pop()
	return adafruit_requests.Session(pool, ssl.create_default_context())

def getLevel(request, url):
	print("Fetching level from " + str(url))
	response = request.get(url)
	#print("Response code: " + str(response.status_code))
	startindex = response.text.index("content=",0,200)
	#print("Level index: " + str(startindex))
	level_import = response.text[startindex+9:response.text.index(';',startindex+9,startindex+90)]
	print(level_import)
	return level_import


def clean_level(level_import):
	level = [list(row) for row in level_import.split(",")]   
	for row in level:
		while len(row) < 8:
			row.append(' ')
	return level
			

if __name__ == "__main__":
	main()
